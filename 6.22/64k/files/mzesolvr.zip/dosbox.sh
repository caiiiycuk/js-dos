while [ true ]; do
	clear
	dosbox
	sleep 1
done
